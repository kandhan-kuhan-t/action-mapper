import setuptools

from distutils.core import setup

setup(
    name='action_mapper',
    version='0.3',
    author='KK',
    author_email='kandhan.kuhan@gmail.com',
    packages=['action_mapper', ],
    license='LICENSE.txt',
    long_description=open('README.txt').read(),
    install_requires=[
        "Django >= 1.1.1",
        "Cerberus == 1.2",
    ],
)